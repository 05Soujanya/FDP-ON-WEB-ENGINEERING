var counter=function(arr){
    return "The length of the arr is :"+arr.length;
}
module.exports.anotherCounter=function(msg){
    return "You called me :"+msg;
}
var adder=function(a,b){
    return `The addition of ${a} and ${b} is : ${a+b}`;
}

module.exports.counter=counter;
module.exports.adder=adder;