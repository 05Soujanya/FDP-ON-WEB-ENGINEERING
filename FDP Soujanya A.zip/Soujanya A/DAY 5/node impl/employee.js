
const express=require('express');
const bodyParser=require('body-parser');
const app =express();

app.use(bodyParser.json());

let empolyees=[
        {"id":1,"name":"Soujanya","dept":"CSE","address":"Hyderabad"},
        {"id":2,"name":"Sunitha","dept":"IT","address":"Secunderabad"},
        {"id":3,"name":"Raghu","dept":"CSE","address":"Hyderabad"},
   ]

app.get('/', (req, res) =>{
    res.json(empolyees)
})
   //app.get('/id,(req,res')=>{
    //for(i=0;i<employees.legnth;i++){
     //   if(employees[i]==parseInt(req.params.id)){
       //     res.json(employee[i]);
         //   break;
        //}
   //})
//    let employee=empolyees.find((employee)=>employee.id === parseInt(req.params.id));
//    if(!employee){
//     res.json({message:`Employee with ${req.params.id} doesnt exists...`})
//     }
//     res.json(employees);
// })
app.post('/',(req,res)=>{
    console.log(req.body);
    let employee={
        id:req.body.id,
        name:req.body.name,
        dept:req.body.dept,
        address:req.body.address
    }
    empolyees.push(employee);
    res.json(employee);
})



    app.put('/:id', (req, res) => {
        let employee = employees.find((employee) => employee.id === parseInt(req.params.id));
        if (!employee) {
            res.json({ message: `Employee with ${req.params.id} doesn't exists..` })
        }
        employee.id = parseInt(req.params.id);
        employee.name = req.body.name;
        employee.dept = req.body.dept;
        employee.address = req.body.address;
    
        res.json(employee);
    
    })
    app.patch('/:id', (req, res) => {
        let employee = employees.find((employee) => employee.id === parseInt(req.params.id));
        if (!employee) {
            res.json({ message: `Employee with ${req.params.id} doesn't exists..` })
        }
        employee.id = parseInt(req.params.id);
        employee.name = req.body.name;
        // employee.dept = req.body.dept;
        // employee.address = req.body.address;
    
        res.json(employee);
    })
    
    
app.listen(3000,()=>console.log("Server listening at port 3000"));