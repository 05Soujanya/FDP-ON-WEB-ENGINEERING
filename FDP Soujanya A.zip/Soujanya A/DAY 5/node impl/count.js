//var counter = function(arr){
  //  return "The length of the arr is : " + arr.length;
//}
//console.log(counter([1,2,3,4]));

var counter=function(arr){
    return "The length of the arr is :"+arr.length;
}

module.exports=counter;


