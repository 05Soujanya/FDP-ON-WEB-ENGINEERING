let arr=[1,2,3,4,5,6]

//for(i=0;i<arr.length;i++)
//console.log(arr[i]);

//arr.forEach((ele)=>{
  //  console.log(ele);
//})

//setTimeout(()=>{
  //  console.log("Timeout function");
//},2000)

//console.log("Outside SetTimeout");

//setInterval(function(){
  //  console.log("Called after 2 seconds");
//},2000);




//var timer=0;
//var interval=setInterval(function(){
   // timer+=2;
    //console.log("called after   "+ timer + " seconds");
    //if(timer > 10)
    //clearInterval(interval);
//},2000);

//console.log(__dirname);

//console.log(__filename);


//Normal function statement
//function sayHello(){
  //  console.log("Hi");
//}
//sayHello();

//function expression
//var sayBye=function(){
  //  console.log("Bye");
//}
//sayBye();



//var counter=require('./count');

//console.log(counter([1,2,3,4]));


//var all =require('./all');

//console.log(all.counter([1,2,3,4]));
//console.log(all.adder(20,30));
//console.log(all.anotherCounter("A Soujanya"));


//var events=require('events');
//var util=require('util');
//var Person=function(name){
  //  this.name=name;
//};
//util.inherits(Person,events.EventEmitter);
//var Soujanya = new Person("Soujanya");
//var Raghu = new Person("Raghu");
//var people = [Soujanya,Raghu];
//people.forEach(function(person){
  //  person.on("speaking",function(){
    //    console.log(person.name+"   is speaking");
   // });
//});
///Soujanya.emit("speaking");

//var myEmitter=new events.EventEmitter();

//myEmitter.on("check",function(message,m2){
   // console.log(message);
    //console.log(m2);
//});

//myEmitter.emit("check","Event Raised","second event");





//Reading the data from file in synchronous 




//var fs=require('fs');

//var dataRead =fs.readFileSync("readMe.txt","utf8");

//console.log(dataRead);


//var fs=require('fs');

//var dataRead =fs.readFileSync("readMe.txt","utf8");

//fs.writeFileSync("WriteMe.txt",dataRead);


//var fs=require('fs');

//fs.readFile("readMe.txt",'utf8',function(err,dataRead){
  //  if(err)
   // console.log("Error in Reading the file content..");
    //else
    //fs.writeFile("writeMe.txt",dataRead,function(err)
    //{
      //  if(err)
       // console.log("Error in Writing the data to the file...");
    //});
//})

//var fs =require('fs');
//fs.mkdir('mydir',function(){
  //  fs.readFile('readMe.txt','utf8',function(err,data)
    //{
      //  fs.writeFile(',./mydir/writeMe.txt',data,function(err){
        //    if(err)
          //  console.log("Error is writing.....");
        //});
    //});
//});

//var http=require('http');
//v//ar server=http.createServer(function(req,res){
   // console.log(req.url);
  //  res.writeHead(200,{'content-type':'data'})
    //res.write("<b>Hello World Response!</b>");
    //res.end();
//});
//server.listen(4321);
//console.log("Server listening at port number 4321");


//var http=require('http');
//var fs=require('fs');
//var server=http.createServer(function(req,res){
  //  console.log(req.url);
    //if(req.url==='/home'){
      //  res.writeHead(200,{'content-type':'text/html'});
        //fs.createReadStream(__dirname+'/index.html').pipe(res);
    //}else if (req.url==='/data'){
    //res.writeHead(200,{'content-type':'application/json'});    
    //var myObj={
      //  name:'A Soujanya',
        //designation:'Associate Professor',
        //department:'CSE',
        //place:'CVR'
    //};
    //res.write(JSON.stringify(myObj));
   // res.end();
//}else{
 //   res.writeHead(404,{'content-type':'text/html'});
   // fs.createReadStream(__dirname+'error.html').pipe(res);//
//}/
//server.listen(4321);
//console.log("server listening at port number 4321");
//var myReadStream=fs.createReadStream(__dirname+'/readMe.txt','utf8');
//var myWriteStream=fs.createWriteStream(__dirname+'/writeMe.txt');
//myReadStream.pipe(myWriteStream)

//var express=require('express');
//var app=express();
//app.get('/',function(req,res){
//res.send("this is the home page");
//});
//app.get('/contact',function(req,res){
  //  res.send("this is the contact page");
//});
//app.listen(1234);


//app.get('/index',(req,res)=>{
//res.sendFile(__dirname+'/index.html');
//})
//app.get('/contactus',(req,res)=>{
  const express=require('express');
  const app =express();
  
  let empolyees=[
      {id:"1",name:"Soujanya",dept:"CSE",address:"Hyderabad"},
     {id:"2",name:"Sunitha",dept:"IT",address:"Secunderabad"},
     {id:"3",name:"Raghu",dept:"CSE",address:"Hyderabad"}
     ]
  
     app.get('/',(req,res)=>{
      res.json(employees);
     })
     app.listen(3000,()=>console.log("Server listening at port 3000"));

