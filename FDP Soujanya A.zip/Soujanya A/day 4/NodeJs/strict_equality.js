const a = 10;
const b = 10;
console.log(a == b); // Outputs True
console.log (a === b); // Outputs True
const str1 = 'abc';
const str2 = 'abc8';
console.log(str1 == str2); // Outputs True
console.log(str1 === str2); // Outputs True
