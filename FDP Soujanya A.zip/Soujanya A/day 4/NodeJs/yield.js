function* gen()  
{  
yield 100;  
yield;  
yield 200;  
}  
// Calling the Generator Function  
var mygen = gen();  
console.log(mygen.next().value); //O/P is 100 because it refers to the first yield
console.log(mygen.next().value); //O/P is undefined because it refers to the second  yield as there is no value
console.log(mygen.next().value); //O/P is 200 because it refers to the third yield as it contains value as 200
