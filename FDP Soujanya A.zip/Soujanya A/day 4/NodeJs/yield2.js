function* show() {
    
yield 100;  
}  
var gen = show();   //here 'gen' is a generator object  
console.log(gen.next()); // { value: 100, done: false }