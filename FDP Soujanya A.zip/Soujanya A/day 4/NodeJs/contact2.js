import contact from './contact.js';
contact('Sara', 25);
// The name is Sara. And age is 25
