const first_name = "Jack";
const last_name = "Sparrow";
console.log('Hello       ' + first_name + '     ' + last_name);