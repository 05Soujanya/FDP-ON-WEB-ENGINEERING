
// function expression using arrow function
let x = (x, y) => x * y;
let sum = (a, b) => {
    let result = a + b;
    return result;
}
let result1 = sum(5,7);
console.log(result1); // 12
