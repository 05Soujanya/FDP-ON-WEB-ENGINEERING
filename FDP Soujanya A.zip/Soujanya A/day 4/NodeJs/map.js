let map1 = new Map();
map1.set('info', {name: "Soujanya", age: "30"});
// access the elements of a Map
console.log(map1.get('info')); // {name: "Soujanya", age: "30"}
