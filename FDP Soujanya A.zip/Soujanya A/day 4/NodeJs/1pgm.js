let x = 10;
console.log(x);
console.log("x=  ",+x);