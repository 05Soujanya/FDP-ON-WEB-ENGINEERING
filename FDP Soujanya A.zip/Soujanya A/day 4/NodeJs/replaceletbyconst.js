const PI = 3.14;
PI=5.35;
console.log(PI);
console.log("x=  ",+PI);
