function sum(x, y = 5) {
    // take sum the value of y is 5 if not passed
    console.log(x + y);
}
sum(5); // 10
sum(5, 15); // 20
