class Person {
  constructor(name) {
    this.name = name;
  }
}
const person1 = new Person('Soujanya');
console.log(person1.name); 
