const person = {
    name: 'Soujanya',
    age: 30,
    gender: 'female'    
}
let name = person.name;
let age = person.age;
let gender = person.gender;
console.log(name); // 
console.log(age); //
console.log(gender); // female
