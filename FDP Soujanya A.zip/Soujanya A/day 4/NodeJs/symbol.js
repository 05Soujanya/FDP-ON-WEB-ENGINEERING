let symbol1 = Symbol('1');
let symbol2 = Symbol('2');
console.log(symbol1 == symbol2); // Outputs False
console.log(symbol1 === symbol2); // Outputs False 
