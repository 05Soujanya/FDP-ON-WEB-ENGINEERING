const person = {
    name: 'Sara',
    age: 25,
    gender: 'female'    
}
let { name, age, gender } = person;
console.log(name); // Sara
console.log(age); // 25
console.log(gender); // female
