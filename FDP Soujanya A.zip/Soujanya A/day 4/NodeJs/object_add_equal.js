let obj1 = { 'id': 1 };
let obj2 = { 'id': 1 };
console.log(obj1 == obj2); // Outputs False
console.log(obj1 === obj2); // Outputs False
