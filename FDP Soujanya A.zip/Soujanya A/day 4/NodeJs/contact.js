export default function contact(name, age) {
        console.log(`The name is ${name}. And age is ${age}.`);
    }
    